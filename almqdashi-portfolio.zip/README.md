# AbdurRahman Almqdashi — Developer Portfolio

A responsive, accessible single-page portfolio highlighting my full-stack development, databases, cloud/DevOps, and AI application skills, along with my projects and contact links.

## Technology

This site is built using semantic HTML, modern CSS, and small, dependency-free JavaScript. It can be hosted as a static site on GitHub Pages, Netlify, or Vercel.

## Preview locally

Open `index.html` in your browser. No build step or package installation is required.

## Deploy to GitHub Pages

1. Create a public repository (suggested name: `developer-portfolio`).
2. Upload the files in this folder to the repository root.
3. Open **Settings → Pages** in GitHub.
4. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/(root)`, and save.
5. Visit the published Pages link once deployment is complete.

## Update content

Edit `index.html` to change your bio, links, skills, projects, or contact email. The skills listed reflect personally reported experience; project features describe the stated goals and scope of the respective projects rather than verified commercial performance.

## Portfolio projects

- **Hydrosolve AI / MissedCall AI** — AI receptionist and dispatch concept for home-service workflows. Website: https://hydrosolveai.com
- **Developer Studio Landing Page** — React/TypeScript frontend project. Source: https://github.com/aalmqdashi2026-crypto/lol

## Accessibility and privacy

Includes semantic sections, a skip link, keyboard-friendly navigation, focus states, responsive layouts, and reduced-motion support. Contact uses `mailto:`; this website does not collect or transmit form data.
